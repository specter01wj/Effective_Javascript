# Effective JavaScript - Code Examples

This repository hosts the code examples from the book.

**Status**:

* Chapter 1: done.
* Chapter 2: done.
