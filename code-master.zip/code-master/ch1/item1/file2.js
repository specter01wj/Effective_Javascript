// file2.js
// no strict mode directive
function g() {
    var arguments = [];
    // ...
}
// ...
