var f = function(x) { return x * 2; };
