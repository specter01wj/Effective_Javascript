var f = function g() { return 17; };
var g = null;
