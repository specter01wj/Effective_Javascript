function double(x) { return x * 2; }
