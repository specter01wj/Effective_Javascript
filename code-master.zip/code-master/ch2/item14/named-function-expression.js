var f = function double(x) { return x * 2; };
